<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST');
header('Access-Control-Allow-Headers: Content-Type');


// Koneksi ke database
$conn = mysqli_connect("localhost", "root", "", "financemanager");

// Cek koneksi
if (!$conn) {
    echo json_encode(["success" => false, "message" => "Koneksi database gagal"]);
    exit();
}

// Ambil data dari POST
$id_user = isset($_POST['id_user']) ? $_POST['id_user'] : null;
$description = isset($_POST['description']) ? $_POST['description'] : null;
$amount = isset($_POST['amount']) ? $_POST['amount'] : null;
$type = isset($_POST['type']) ? $_POST['type'] : null;

// Debug untuk mengecek data POST
file_put_contents("debug_log_transaction.txt", json_encode($_POST) . PHP_EOL, FILE_APPEND);

// Validasi data
if (empty($id_user) || empty($description) || empty($amount) || empty($type)) {
    echo json_encode(["success" => false, "message" => "Data tidak lengkap"]);
    exit();
}

// Query untuk menambahkan transaksi
$query = "INSERT INTO transactions (id_user, description, amount, type, created_at) VALUES (?, ?, ?, ?, NOW())";
$stmt = mysqli_prepare($conn, $query);
mysqli_stmt_bind_param($stmt, "isds", $id_user, $description, $amount, $type);

if (mysqli_stmt_execute($stmt)) {
    echo json_encode(["success" => true, "message" => "Transaksi berhasil ditambahkan"]);
} else {
    echo json_encode(["success" => false, "message" => "Gagal menyimpan transaksi"]);
}

// Tutup koneksi
mysqli_close($conn);
?>
