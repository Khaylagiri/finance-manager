-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jan 19, 2025 at 06:20 PM
-- Server version: 8.0.30
-- PHP Version: 8.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `financemanager`
--

-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

CREATE TABLE `transactions` (
  `id_transactions` int NOT NULL,
  `id_user` int NOT NULL,
  `type` enum('pemasukan','pengeluaran') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `transactions`
--

INSERT INTO `transactions` (`id_transactions`, `id_user`, `type`, `amount`, `description`, `created_at`) VALUES
(1, 1, 'pemasukan', '5000000.00', 'Gaji Januari', '2025-01-18 01:36:13');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id_user` int NOT NULL,
  `fullname` varchar(100) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone_number` varchar(15) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id_user`, `fullname`, `username`, `email`, `phone_number`, `password`, `created_at`, `updated_at`, `status`) VALUES
(1, 'khayla', 'khayla', 'khayla@gmail.com', '087737241139', '12345678', '2025-01-16 02:49:52', '2025-01-16 02:49:52', 'active'),
(2, 'fitri', 'fitri', 'fitri@gmail.com', '087887397196', '12345678', '2025-01-16 02:50:36', '2025-01-16 02:50:36', 'active'),
(3, 'khaylagiri', 'khaylaf', 'khaylagirif@gmail.com', '087737241139', 'Khayla123', '2025-01-16 10:35:25', '2025-01-16 10:35:25', 'active'),
(4, 'lala', 'lala', 'lalal@gmail.com', '089762345678', '$2y$10$JQFlsKn5CWPTWfjEXW1waeI0d3gM7JzRb52vhncIpuQcU4pyr7ofS', '2025-01-19 10:37:34', '2025-01-19 10:37:34', 'active'),
(5, 'khayla giri', 'khay', 'khay@gmail.com', '089734567', '$2y$10$eKlg8PY0R2wlC4OWebXAveKOvHGP/5INXRVjLSLL9rfdoprJuGWMe', '2025-01-19 11:09:07', '2025-01-19 11:09:07', 'active'),
(6, 'KHAYLA GIRI FITRIANI', 'khaylagirif', 'khayla123@gmail.com', '098345678', '$2y$10$lIVbiROSsKA7FcpZt25bEu56WJgmP2pUu2zvzxPtInWkJJt9elFJW', '2025-01-19 14:52:30', '2025-01-19 14:52:30', 'active'),
(7, 'khayla giri f', 'khayla23', 'khayla23@gmail.com', '09993446788', '$2y$10$YNBMqGQ2ikklrLr8iQaB6ObAdVkDFKceJYVV3Gz.cZTuWAwjLmXCi', '2025-01-19 17:20:02', '2025-01-19 17:20:02', 'active'),
(8, 'laila', 'laila12', 'laila12@gmail.com', '0098645678', '$2y$10$QwhJfNTGuJZW3P2Lqw6GIuJvOHGJ4FykNBqwzr9mucOlUgu7sDTCO', '2025-01-19 17:26:27', '2025-01-19 17:26:27', 'active'),
(9, 'fitria', 'fitria20', 'fitria20@gmail.com', '0995678', '$2y$10$RH2KbQet5Ut2e2W3buhHeuyugmJVO2VpfBPSB6Ms5v60jGdtgJbha', '2025-01-19 17:34:14', '2025-01-19 17:34:14', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `user_logs`
--

CREATE TABLE `user_logs` (
  `id_log` int NOT NULL,
  `id_user` int NOT NULL,
  `activity` varchar(255) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `user_logs`
--

INSERT INTO `user_logs` (`id_log`, `id_user`, `activity`, `timestamp`) VALUES
(1, 1, 'login', '2025-01-18 09:23:45');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `transactions`
--
ALTER TABLE `transactions`
  ADD PRIMARY KEY (`id_transactions`),
  ADD KEY `id_user` (`id_user`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id_user`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `user_logs`
--
ALTER TABLE `user_logs`
  ADD PRIMARY KEY (`id_log`),
  ADD KEY `id_user` (`id_user`),
  ADD KEY `id_user_2` (`id_user`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id_user` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `user_logs`
--
ALTER TABLE `user_logs`
  MODIFY `id_log` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `transactions`
--
ALTER TABLE `transactions`
  ADD CONSTRAINT `transactions_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `user` (`id_user`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `user_logs`
--
ALTER TABLE `user_logs`
  ADD CONSTRAINT `user_logs_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `user` (`id_user`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
