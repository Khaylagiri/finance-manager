<?php
header('Content-Type: application/json; charset=utf-8');
include 'db_connection.php';

try {
    $sql = "SELECT l.id_log, u.fullname, l.activity, l.timestamp 
            FROM user_logs l
            JOIN user u ON l.id_user = u.id_user
            ORDER BY l.timestamp DESC";
    $result = $conn->query($sql);

    if (!$result) {
        throw new Exception("Query failed: " . $conn->error);
    }

    if ($result->num_rows === 0) {
        echo json_encode(["success" => false, "message" => "No logs found"]);
        exit;
    }

    $data = [];
    while ($row = $result->fetch_assoc()) {
        $data[] = $row;
    }

    echo json_encode(["success" => true, "data" => $data]);
} catch (Exception $e) {
    echo json_encode(["success" => false, "message" => $e->getMessage()]);
} finally {
    $conn->close();
}
?>
