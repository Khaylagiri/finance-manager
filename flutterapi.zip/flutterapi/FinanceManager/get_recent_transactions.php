<?php
// Aktifkan debugging untuk pengembangan (hapus di produksi)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Header untuk memastikan respons JSON
header('Content-Type: application/json; charset=utf-8');

// Debugging log file (untuk melihat permintaan yang masuk)
file_put_contents('debug_log_transactions.txt', "Request received: " . date('Y-m-d H:i:s') . "\n", FILE_APPEND);

// Koneksi ke database
$host = 'localhost'; // Ganti jika menggunakan IP LAN
$username = 'root'; // Username database Anda
$password = ''; // Password database Anda
$database = 'financemanager'; // Nama database Anda

// Buat koneksi
$conn = new mysqli($host, $username, $password, $database);

// Periksa koneksi database
if ($conn->connect_error) {
    die(json_encode([
        "success" => false,
        "message" => "Koneksi database gagal: " . $conn->connect_error
    ]));
}

try {
    // Query untuk mendapatkan transaksi terbaru
    $sql = "SELECT t.created_at AS date, u.fullname AS username, t.description, t.amount 
            FROM transactions t
            JOIN user u ON t.id_user = u.id_user
            ORDER BY t.created_at DESC 
            LIMIT 5"; // Ambil 5 transaksi terbaru

    // Debugging log untuk query
    file_put_contents('debug_log_transactions.txt', "Query executed: " . $sql . "\n", FILE_APPEND);

    // Eksekusi query
    $result = $conn->query($sql);

    if (!$result) {
        throw new Exception("Query gagal: " . $conn->error);
    }

    // Proses hasil query
    $data = [];
    while ($row = $result->fetch_assoc()) {
        $data[] = $row;
    }

    // Jika data kosong
    if (empty($data)) {
        echo json_encode([
            "success" => false,
            "message" => "Tidak ada data transaksi terbaru."
        ], JSON_PRETTY_PRINT);
        exit();
    }

    // Debugging log untuk data hasil query
    file_put_contents('debug_log_transactions.txt', "Data fetched: " . json_encode($data) . "\n", FILE_APPEND);

    // Tampilkan data dalam format JSON
    echo json_encode([
        "success" => true,
        "data" => $data
    ], JSON_PRETTY_PRINT);
} catch (Exception $e) {
    // Tampilkan pesan error jika ada masalah
    echo json_encode([
        "success" => false,
        "message" => $e->getMessage()
    ], JSON_PRETTY_PRINT);
    file_put_contents('debug_log_transactions.txt', "Error: " . $e->getMessage() . "\n", FILE_APPEND);
} finally {
    // Tutup koneksi database
    $conn->close();
    file_put_contents('debug_log_transactions.txt', "Connection closed\n", FILE_APPEND);
}
?>
