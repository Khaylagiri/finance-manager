<?php
// Aktifkan debugging (hapus ini di produksi)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Header untuk memastikan respons JSON
header('Content-Type: application/json; charset=utf-8');

// Koneksi ke database
$conn = mysqli_connect("localhost", "root", "", "financemanager");

// Periksa koneksi
if (!$conn) {
    echo json_encode(["success" => false, "message" => "Koneksi database gagal: " . mysqli_connect_error()]);
    exit();
}

// Pastikan metode HTTP adalah POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(["success" => false, "message" => "Metode tidak diizinkan"]);
    exit();
}

// Ambil data dari Flutter
$email = isset($_POST['email']) ? trim($_POST['email']) : null;
$password = isset($_POST['password']) ? trim($_POST['password']) : null;

// Validasi input
if (empty($email) || empty($password)) {
    echo json_encode(["success" => false, "message" => "Email atau password tidak boleh kosong"]);
    exit();
}

// Query untuk mendapatkan user berdasarkan email
$query = "SELECT * FROM user WHERE email = ?";
$stmt = mysqli_prepare($conn, $query);
mysqli_stmt_bind_param($stmt, "s", $email);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if (mysqli_num_rows($result) > 0) {
    $user = mysqli_fetch_assoc($result);

    // Validasi password menggunakan password_verify
    if (password_verify($password, $user['password'])) {
        echo json_encode([
            "success" => true,
            "message" => "Login berhasil",
            "user" => [
                "id_user" => $user['id_user'],
                "fullname" => $user['fullname'],
                "email" => $user['email'],
                "phone_number" => $user['phone_number'],
                "status" => $user['status']
            ]
        ]);
    } else {
        echo json_encode(["success" => false, "message" => "Password salah"]);
    }
} else {
    echo json_encode(["success" => false, "message" => "Email tidak ditemukan"]);
}

// Tutup koneksi database
mysqli_close($conn);
?>
