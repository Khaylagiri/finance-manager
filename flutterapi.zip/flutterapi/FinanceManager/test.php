<?php
echo "File berhasil diakses!";
?>
