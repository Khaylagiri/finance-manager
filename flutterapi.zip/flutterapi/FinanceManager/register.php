<?php
// Aktifkan debugging (hapus ini di produksi)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Header untuk JSON
header('Content-Type: application/json; charset=UTF-8');

// Koneksi ke database
$conn = mysqli_connect("localhost", "root", "", "financemanager");

// Periksa koneksi database
if (!$conn) {
    echo json_encode(["success" => false, "message" => "Koneksi database gagal: " . mysqli_connect_error()]);
    exit();
}

// Pastikan metode HTTP adalah POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(["success" => false, "message" => "Metode tidak diizinkan"]);
    exit();
}

// Ambil data dari Flutter
$fullname = isset($_POST['fullname']) ? trim($_POST['fullname']) : null;
$username = isset($_POST['username']) ? trim($_POST['username']) : null;
$email = isset($_POST['email']) ? trim($_POST['email']) : null;
$phone_number = isset($_POST['phone_number']) ? trim($_POST['phone_number']) : null;
$password = isset($_POST['password']) ? trim($_POST['password']) : null;

// Validasi input
if (empty($fullname) || empty($username) || empty($email) || empty($phone_number) || empty($password)) {
    echo json_encode(["success" => false, "message" => "Semua data harus diisi"]);
    exit();
}

// Periksa apakah username atau email sudah ada
$checkQuery = "SELECT * FROM user WHERE username = ? OR email = ?";
$stmt = mysqli_prepare($conn, $checkQuery);
mysqli_stmt_bind_param($stmt, "ss", $username, $email);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if (mysqli_num_rows($result) > 0) {
    echo json_encode(["success" => false, "message" => "Username atau email sudah digunakan"]);
    exit();
}

// Hash password sebelum menyimpan
$hashedPassword = password_hash($password, PASSWORD_BCRYPT);

// Masukkan data ke dalam tabel user
$insertQuery = "INSERT INTO user (fullname, username, email, phone_number, password, status, created_at, updated_at) 
                VALUES (?, ?, ?, ?, ?, 'active', NOW(), NOW())";
$stmt = mysqli_prepare($conn, $insertQuery);
mysqli_stmt_bind_param($stmt, "sssss", $fullname, $username, $email, $phone_number, $hashedPassword);
$execute = mysqli_stmt_execute($stmt);

if ($execute) {
    echo json_encode(["success" => true, "message" => "Registrasi berhasil"]);
} else {
    echo json_encode(["success" => false, "message" => "Gagal melakukan registrasi"]);
}

// Tutup koneksi
mysqli_close($conn);
?>
