<?php
// Menghubungkan ke database
$conn = mysqli_connect("localhost", "root", "", "financemanager");

// Memeriksa apakah koneksi berhasil
if (!$conn) {
    die(json_encode(["error" => "Koneksi gagal: " . mysqli_connect_error()]));
}

// Query untuk mendapatkan data pengguna
$query = "SELECT id_user, fullname, username, email, phone_number, status FROM user";
$result = mysqli_query($conn, $query);

// Memeriksa apakah query berhasil
if (!$result) {
    die(json_encode(["error" => "Query gagal: " . mysqli_error($conn)]));
}

// Mengambil data dalam array
$data = mysqli_fetch_all($result, MYSQLI_ASSOC);

// Menampilkan data dalam format JSON
header('Content-Type: application/json');
echo json_encode($data);

// Menutup koneksi
mysqli_close($conn);
?>
