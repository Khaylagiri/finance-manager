<?php
header('Content-Type: application/json');

// Koneksi ke database
$conn = mysqli_connect("localhost", "root", "", "financemanager");

// Cek koneksi
if (!$conn) {
    echo json_encode(["success" => false, "message" => "Koneksi database gagal"]);
    exit();
}

// Ambil data dari POST
$id_user = isset($_POST['id_user']) ? $_POST['id_user'] : null;

// Debug untuk memeriksa apakah ID pengguna diterima
file_put_contents("debug_log.txt", "ID User: $id_user\n", FILE_APPEND);

// Validasi data
if (empty($id_user) || !is_numeric($id_user)) {
    echo json_encode(["success" => false, "message" => "ID pengguna tidak valid"]);
    exit();
}

// Query untuk mendapatkan transaksi
$query = "SELECT * FROM transactions WHERE id_user = ? ORDER BY created_at DESC";
$stmt = mysqli_prepare($conn, $query);
mysqli_stmt_bind_param($stmt, "i", $id_user);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

// Ambil data transaksi
$transactions = [];
while ($row = mysqli_fetch_assoc($result)) {
    $transactions[] = $row;
}

echo json_encode(["success" => true, "transactions" => $transactions]);

// Tutup koneksi
mysqli_close($conn);
?>
