<?php
// Aktifkan debugging (hapus di produksi)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Header untuk memastikan respons JSON
header('Content-Type: application/json; charset=utf-8');

// Koneksi ke database
$conn = mysqli_connect("localhost", "root", "", "financemanager");

// Cek koneksi database
if (!$conn) {
    echo json_encode(["success" => false, "message" => "Koneksi database gagal"]);
    exit();
}

try {
    // Query untuk mendapatkan data transaksi
    $sql = "SELECT 
                t.id_user AS id_user,
                u.fullname AS fullname,
                CAST(SUM(CASE WHEN t.type = 'pemasukan' THEN t.amount ELSE 0 END) AS UNSIGNED) AS total_pemasukan,
                CAST(SUM(CASE WHEN t.type = 'pengeluaran' THEN t.amount ELSE 0 END) AS UNSIGNED) AS total_pengeluaran
            FROM transactions t
            INNER JOIN user u ON t.id_user = u.id_user
            GROUP BY t.id_user";

    // Eksekusi query
    $result = mysqli_query($conn, $sql);

    if (!$result) {
        throw new Exception("Query gagal: " . mysqli_error($conn));
    }

    // Array untuk menyimpan data
    $data = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $data[] = $row;
    }

    // Pastikan data tidak kosong
    if (empty($data)) {
        echo json_encode(["success" => false, "message" => "Tidak ada data ditemukan"]);
        exit();
    }

    // Tampilkan data dalam format JSON
    echo json_encode(["success" => true, "data" => $data], JSON_PRETTY_PRINT);
} catch (Exception $e) {
    // Tampilkan pesan error jika ada masalah
    echo json_encode(["success" => false, "message" => $e->getMessage()]);
} finally {
    // Tutup koneksi database
    mysqli_close($conn);
}
?>
