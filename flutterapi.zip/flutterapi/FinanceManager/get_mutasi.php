<?php
header('Content-Type: application/json; charset=utf-8');
include 'db_connection.php';

// Debug: Log data POST dan GET
error_log("Received POST Data: " . print_r($_POST, true));
error_log("Received GET Data: " . print_r($_GET, true));

$id_user = $_POST['id_user'] ?? $_GET['id_user'] ?? null;

if (!$id_user) {
    error_log("Error: User ID not provided");
    echo json_encode(["success" => false, "message" => "User ID not provided"]);
    exit;
}

try {
    $sql = "SELECT type, amount, description, created_at 
            FROM transactions 
            WHERE id_user = ? 
            ORDER BY created_at DESC";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('i', $id_user);
    $stmt->execute();
    $result = $stmt->get_result();

    $data_pemasukan = [];
    $data_pengeluaran = [];
    while ($row = $result->fetch_assoc()) {
        if ($row['type'] === 'pemasukan') {
            $data_pemasukan[] = $row;
        } elseif ($row['type'] === 'pengeluaran') {
            $data_pengeluaran[] = $row;
        }
    }

    echo json_encode([
        "success" => true,
        "data" => [
            "pemasukan" => $data_pemasukan,
            "pengeluaran" => $data_pengeluaran,
        ],
    ]);
} catch (Exception $e) {
    error_log("Error: " . $e->getMessage());
    echo json_encode(["success" => false, "message" => $e->getMessage()]);
} finally {
    $conn->close();
}
?>
